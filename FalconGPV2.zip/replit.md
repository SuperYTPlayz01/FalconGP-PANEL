# Running the panel on Replit

- Start the app with `npm start`.
- The Replit workflow runs `PORT=5000 npm start` so the web preview can reach it.
- The app stores its SQLite database in `database.db` in the project root.

The sign-in page should load in the Replit preview after the workflow starts.

## Docker server runtime

New servers default to Docker. The host running FalconGP must have the Docker CLI installed, a reachable Docker daemon, and permission to start containers. The panel pulls an `itzg/minecraft-server` image on first start, choosing Java from the Minecraft version (or the administrator's explicit Java selection); Java does not need to be installed on the host.

Docker runtime currently supports Vanilla, Paper, Purpur, Fabric, Forge, Quilt, and Spigot. Bedrock, proxy, and other server software must use the legacy local runtime. Server files persist in the panel's server directory, and Docker applies the configured RAM and CPU limits. Stop requests use Docker's graceful container shutdown rather than sending the Minecraft `stop` command over RCON, which is rejected by some Paper-derived server versions.

Linux Bedrock servers run natively without Java. The panel repairs the `bedrock_server` executable permission when starting and sets `LD_LIBRARY_PATH` to the server directory so bundled libraries load correctly.

Bedrock servers have an **Add-ons** page for MCPEDL search and CurseForge search/install. CurseForge search and automatic installation require `CURSEFORGE_API_KEY`. MCPEDL serves files through its own download pages, so download a `.mcpack` or `.mcaddon` there and upload it to the panel. Add-on archives are unpacked into the Bedrock behavior/resource pack directories and activated for the world configured by `level-name` in `server.properties`. Stop the server before installing or updating packs.

Administrators can use **Admin Panel → Docker Management** to view container health and live CPU/memory usage, read recent container logs, and start, stop, or restart Docker servers. Pulling and applying an image update briefly stops and recreates the container while preserving the server's bind-mounted files. The current image is pinned by ID, and FalconGP attempts to roll back to the previous image if the updated one fails to start. CPU and memory alert thresholds can be configured on this page; alerts notify the server owner and active panel administrators and re-arm after usage returns below the threshold.

## Falcon Journey queue

User-requested server starts and restarts use the persistent Falcon Journey queue. Queue entries and queue configuration are stored in `database.db`, restored after a panel restart, and processed in FIFO order (with admin-adjustable priority). Administrators with the existing server-management permission can pause/resume the queue, manage waiting entries, and edit queue behavior at **Admin Panel → Falcon Queue → Queue configuration**. Saved admin settings take precedence over environment defaults and apply immediately.

Configure the queue with environment variables:

- `FALCON_QUEUE_ENABLED` (default `true`): set to `false` to preserve direct starts/restarts without the queue.
- `FALCON_QUEUE_MAX_CONCURRENT` (default `1`): maximum simultaneous queued start/restart operations.
- `FALCON_QUEUE_MAX_WAITING` (default `0`): maximum number of waiting entries; `0` is unlimited.
- `FALCON_QUEUE_GRACE_PERIOD` (default `60`): seconds without a journey-page heartbeat before a waiting entry is cancelled; `0` disables expiration.
- `FALCON_QUEUE_ESTIMATION_ENABLED` (default `true`) and `FALCON_QUEUE_ESTIMATED_SECONDS_PER_SLOT` (default `90`): show estimated queue wait.
- `FALCON_QUEUE_CINEMATIC` (default `true`): disable animated effects while retaining accessible queue status.
- `FALCON_QUEUE_SOUND_DEFAULT` (default `false`): initial sound setting; users can toggle the subtle optional UI tone.

Admins can configure whether the queue is enabled, deployment concurrency, waiting capacity, grace timeout (seconds/minutes), ETA display and rate (seconds/minutes), cinematic effects, and default sound. Disabling the queue sends new start/restart requests directly to the existing server actions; already queued work is allowed to drain. No manual database migration or additional dependency is required; the panel creates the queue tables and indexes on startup.
